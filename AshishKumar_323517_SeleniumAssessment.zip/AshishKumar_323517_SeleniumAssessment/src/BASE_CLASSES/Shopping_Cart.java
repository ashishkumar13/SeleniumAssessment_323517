package BASE_CLASSES;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Shopping_Cart {
	
WebDriver dr;
	
	@FindBy(xpath = "//a[text() ='Home']")
	WebElement home;
	
	
	public Shopping_Cart(WebDriver dr) {
		this.dr = dr;
		PageFactory.initElements(dr, this);
	}
	
	public void clickHome() {
		home.click();
	}
	
	public String[] actualProducts() {
		String[] actualNames = new String[2]; 
		actualNames[0] = dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr[2]/td[1]")).getText();
		actualNames[1] = dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr[3]/td[1]")).getText();
		return actualNames;
	}
	
	public String[] actualProductTotal() {
		String[] actualTotal = new String[2];
		actualTotal[0] = dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr[2]/td[4]")).getText();
		actualTotal[1] = dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr[3]/td[4]")).getText();
		return actualTotal;
	}
	
}
