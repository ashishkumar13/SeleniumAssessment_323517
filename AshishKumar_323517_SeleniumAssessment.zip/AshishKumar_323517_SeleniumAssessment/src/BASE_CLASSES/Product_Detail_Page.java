package BASE_CLASSES;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Product_Detail_Page {
	
	WebDriver dr;

	@FindBy(xpath = "//input[@name='quantity']")  
	WebElement qtyField;
	
	@FindBy(xpath = "//input[@name ='Insert1']")
	WebElement addBtn;
	
	public Product_Detail_Page(WebDriver dr) {
		this.dr = dr;
		PageFactory.initElements(dr, this);
	}
	
	public String verifyTitle() {
		return dr.getTitle(); 
	}
	
	public void clearQuantity() {
		dr.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		dr.findElement(By.xpath("//input[@name='quantity']")).clear();;
	}
	
	public void inputQuantity(String s) {
		qtyField.sendKeys(s);
	}
	
	public void clickAdd() {
		addBtn.click();
	}
	
}
