package BASE_CLASSES;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class Home_Page {
	
	WebDriver dr;
	
	
	@FindBy(xpath = "/html/body/table[5]/tbody/tr/td[1]/form/table[1]/tbody/tr/th")
	WebElement searchText;
	
	@FindBy(xpath = "//select[@name = 'category_id']")
	WebElement selectPath;
	
	@FindBy(xpath = "//input[@name = 's_keyword']")
	WebElement inputField;
	
	@FindBy(xpath = "//input[@name = 'DoSearch']")
	WebElement searchBtn;
	
	
	public Home_Page(WebDriver dr) {
		this.dr = dr;
		PageFactory.initElements(dr, this);
	}
	
	public String verifyTitle() {
		return dr.getTitle(); 
	}
	
	
	public String verifySearchProdut() {
		return searchText.getText();
	}
	
	public void performSearch(String category, String data) {
		Select sel = new Select(selectPath);
		sel.selectByVisibleText(category);	
		
		inputField.sendKeys(data);
		
		searchBtn.click();	
		
	}
	
}
