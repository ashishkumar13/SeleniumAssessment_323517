package BASE_CLASSES;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Search_Results_Page {
	
	
	WebDriver dr;
	String actual;
				   
	@FindBy(xpath = "/html/body/table[5]/tbody/tr/td/table[2]/tbody/tr[1]/td[2]/b/a")
	WebElement book;
	
	public Search_Results_Page(WebDriver dr) {
		this.dr = dr;
		PageFactory.initElements(dr, this);
	}
	
	public String verifyTitle() {
		return dr.getTitle(); 
	}
	
	public void clickProduct() {
		book.click();
	}


}
