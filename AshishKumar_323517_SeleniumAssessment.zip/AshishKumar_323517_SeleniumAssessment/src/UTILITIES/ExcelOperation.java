package UTILITIES;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelOperation {
	
	public ArrayList<TestData> readTestData() {
		
		ArrayList<TestData> testDatas = new ArrayList<TestData>();
		File file = new File("Book1.xlsx");
		XSSFWorkbook wb;
		XSSFSheet sh;
		XSSFRow row;
		XSSFCell cell1, cell2, cell3;
		
		try {
			FileInputStream fis = new FileInputStream(file);
			wb = new XSSFWorkbook(fis);
			
			sh = wb.getSheet("Sheet1");
			
			for(int i = 2; i<4; i++) {
				TestData td = new TestData();
				
				row = sh.getRow(i);
				cell1 = row.getCell(0);
				td.setCategory(cell1.getStringCellValue());
				
				cell2 = row.getCell(1);
				td.setSearchString(cell2.getStringCellValue());
				
				cell3 = row.getCell(2);
				td.setQuantity(Integer.toString((int) cell3.getNumericCellValue()));				
				
				testDatas.add(td);
			}
			
			
		} catch ( IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return testDatas;
	}

	public String[] readProductNames() {
		String [] productNames = new String[2];
		File file = new File("Book1.xlsx");
		XSSFWorkbook wb;
		XSSFSheet sh;
		XSSFRow row;
		XSSFCell cell1;
		
		try {
			FileInputStream fis = new FileInputStream(file);
			wb = new XSSFWorkbook(fis);
			sh = wb.getSheet("Sheet2");
			row = sh.getRow(2);
			cell1 = row.getCell(0);
			productNames[0] = cell1.getStringCellValue();
					
			row = sh.getRow(3);
			cell1 = row.getCell(0);
			productNames[1] = cell1.getStringCellValue();
			
		}
		catch (IOException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
			
		return productNames;
	}
	
	public String[] readProductTotal() {
		String [] productTotal = new String[2];
		File file = new File("Book1.xlsx");
		XSSFWorkbook wb;
		XSSFSheet sh;
		XSSFRow row;
		XSSFCell cell1;
		
		try {
			FileInputStream fis = new FileInputStream(file);
			wb = new XSSFWorkbook(fis);
			sh = wb.getSheet("Sheet2");
			row = sh.getRow(2);
			cell1 = row.getCell(1);
			productTotal[0] = "$"+Double.toString(cell1.getNumericCellValue());
					
			row = sh.getRow(3);
			cell1 = row.getCell(1);
			productTotal[1] = "$"+Double.toString(cell1.getNumericCellValue());
			
		}
		catch (IOException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
			
		return productTotal;
	}
	
}


