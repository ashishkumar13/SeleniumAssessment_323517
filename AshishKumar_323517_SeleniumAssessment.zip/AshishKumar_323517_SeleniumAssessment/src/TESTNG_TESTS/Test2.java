package TESTNG_TESTS;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;



public class Test2 extends Test1{
	String[] products;
	String[] total;
	
	@Test(priority = 11, dataProvider = "productNameProvider")
	public void u2_productDetail(String act, String exp) {  // verify Product
		log.info("Expected Result: "+ exp);
		log.info("Actual Result: "+ act);
		sa.assertEquals(act, exp);
		sa.assertAll();
		
	}
	
	@DataProvider(name = "productNameProvider")
	public String[][] nameProvider() {		
		String[] actualN = sc.actualProducts();
		String[]expectedN = eo.readProductNames();
		String [][] data = { {actualN[0], expectedN[0]}, 
							 {actualN[1], expectedN[1]}
							};		
		return data;
	}
		
	@Test(priority = 12, dataProvider = "productTotalProvider")
	public void u3_productDetail(String act, String exp) {
		log.info("Expected Result: "+ exp);
		log.info("Actual Result: "+ act);
		sa.assertEquals(act, exp);
		sa.assertAll();
	}
	
	@DataProvider(name = "productTotalProvider")
	public String[][] totalProvider() {
		String[] actualT = sc.actualProductTotal();
		String[] expectedT = eo.readProductTotal();
		String [][] dataT = { {actualT[0], expectedT[0]}, 
							 {actualT[1], expectedT[1]}
							};
		return dataT;
 	}
	
	
	
}
