package TESTNG_TESTS;

import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import BASE_CLASSES.Home_Page;
import BASE_CLASSES.Product_Detail_Page;
import BASE_CLASSES.Search_Results_Page;
import BASE_CLASSES.Shopping_Cart;
import UTILITIES.ExcelOperation;
import UTILITIES.TestData;


@Listeners(UTILITIES.ListenerLog.class)
public class Test1 {
	
	ExcelOperation eo;
	ArrayList<TestData> testDatas;
	WebDriver dr;
	
	Home_Page hp;
	Search_Results_Page srp;
	Product_Detail_Page pdp;
	Shopping_Cart sc;
	
	Logger log =  Logger.getLogger("devpinoyLogger");
	String expected;
	String actual;
	
	String homeUrl = "http://examples.codecharge.com/Store/Default.php";
	
	SoftAssert sa;
	
	@BeforeClass
	public void launch() {
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		dr = new ChromeDriver();
		dr.get(homeUrl);
		
		eo = new ExcelOperation();
		testDatas = eo.readTestData();
		
		sa = new SoftAssert();
		hp = new Home_Page(dr);
		srp = new Search_Results_Page(dr);
		pdp = new Product_Detail_Page(dr);
		sc = new Shopping_Cart(dr);
		 
	}
	
	
	
	@Test(priority = 1)
	public void t1_homepage() {    // verify Title homepage
		expected = "Online Bookstore";		
		actual = hp.verifyTitle();
		log.info("Expected Result: "+ expected);
		log.info("Actual Result: "+ actual);
		sa.assertEquals(actual, expected);
		sa.assertAll();
	}
	
	@Test(priority = 2)
	public void t2_homepage() {		// verify text - "Search Products".
		expected = "Search Products";
		actual = hp.verifySearchProdut();
		
		log.info("Expected Result: "+ expected);
		log.info("Actual Result: "+ actual);
		Assert.assertEquals(actual, expected);
		hp.performSearch(testDatas.get(0).getCategory(), testDatas.get(0).getSearchString());
	}
	
	@Test(priority = 3)
	public void t3_searchResult() {
		expected = "SearchResults";		
		actual = srp.verifyTitle();
		
		log.info("Expected Result: "+ expected);
		log.info("Actual Result: "+ actual);
		Assert.assertEquals(actual, expected);
		srp.clickProduct();
	}
	
	@Test(priority = 4)
	public void t4_productDeatail() {
		expected = "ProductDetail";		
		actual = pdp.verifyTitle();
		
		log.info("Expected Result: "+ expected);
		log.info("Actual Result: "+ actual);
		sa.assertEquals(actual, expected);
		sa.assertAll();
	}
	
	@Test(priority = 5)
	public void t5_productDeatail() {
		pdp.clearQuantity();
		
		log.info("Expected Result: "+ expected);
		log.info("Actual Result: "+ actual);
		pdp.inputQuantity(testDatas.get(0).getQuantity());
		pdp.clickAdd();
		sc.clickHome();
	}
	
	
	@Test(priority = 6)
	public void t6_homepage() {    // verify Title homepage
		expected = "Online Bookstore";		
		actual = hp.verifyTitle();
		
		log.info("Expected Result: "+ expected);
		log.info("Actual Result: "+ actual);
		sa.assertEquals(actual, expected);
		sa.assertAll();
	}
	
	@Test(priority = 7)
	public void t7_homepage() {		// verify text - "Search Products".
		expected = "Search Products";
		actual = hp.verifySearchProdut();
		
		log.info("Expected Result: "+ expected);
		log.info("Actual Result: "+ actual);
		Assert.assertEquals(actual, expected);
		hp.performSearch(testDatas.get(1).getCategory(), testDatas.get(1).getSearchString());
	}
	
	@Test(priority = 8)
	public void t8_searchResult() {
		expected = "SearchResults";		
		actual = srp.verifyTitle();
		
		log.info("Expected Result: "+ expected);
		log.info("Actual Result: "+ actual);
		Assert.assertEquals(actual, expected);
		srp.clickProduct();
	}
	
	@Test(priority = 9)
	public void t9_productDeatail() {
		expected = "ProductDetail";		
		actual = pdp.verifyTitle();
		log.info("Expected Result: "+ expected);
		log.info("Actual Result: "+ actual);
		sa.assertEquals(actual, expected);
		sa.assertAll();
	}
	
	@Test(priority = 10)
	public void u1_productDetai() {
		pdp.clearQuantity();
		pdp.inputQuantity(testDatas.get(1).getQuantity());
		pdp.clickAdd();
		dr.findElement(By.xpath("/html/body/table[2]/tbody/tr/td/a[3]")).click();
	}
	
}

